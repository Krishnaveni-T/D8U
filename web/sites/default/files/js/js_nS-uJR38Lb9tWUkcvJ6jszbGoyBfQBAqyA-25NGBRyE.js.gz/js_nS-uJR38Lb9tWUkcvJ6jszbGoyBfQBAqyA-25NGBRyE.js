/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.childtheme_barrio = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
